from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.security import OAuth2PasswordBearer
import httpx
from starlette.config import Config
from typing import List
from pydantic import BaseModel
from typing import List
from pydantic import BaseModel
from okta_jwt.jwt import validate_token as validate_locally

config = Config('.env')

app = FastAPI()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl='token')

def retrieve_token(authorization, issuer, scope='items'):
	headers = {
		'accept': 'application/json',
		'authorization': authorization,
		'cache-control': 'no-cache',
		'content-type': 'application/x-www-form-urlencoded'
	}
	data = {
		'grant_type': 'client_credentials',
		'scope': scope,
	}
	url = issuer + '/v1/token'
	response = httpx.post(url, headers=headers, data=data)

	if response.status_code == httpx.codes.OK:
		return response.json()
	else:
		raise HTTPException(status_code=400, detail=response.text)
# Get auth token endpoint

#@app.post('/token')
#def login(request: Request):
#	return retrieve_token(
#		request.headers['authorization'],#
#		config('OKTA_ISSUER'),
#		'items'
#	)
@app.post('/token')
def login(request:Request):
	return retrieve_token(
		request.headers['authorization'],
		#'authorization',
		config('OKTA_ISSUER'),
		config('OKTA_SCOPE')
	)

def retrieve_tokenlangsung(issuer, scope):
	data = {
		'grant_type': 'client_credentials',
		'scope': scope,
	}
	url = issuer + '/v1/token'
	client_id = config('OKTA_CLIENT_ID')
	client_secret = config('OKTA_CLIENT_SECRET')
	response = httpx.post(url, data=data, verify=False, allow_redirects=False, auth=(client_id, client_secret))
	if response.status_code == httpx.codes.OK:
		return response.json()
	else:
		raise HTTPException(status_code=400, detail=response.text)
# Get auth token endpoint

@app.post('/tokenlangsung')
def login(request: Request):
	return retrieve_tokenlangsung(
		config('OKTA_ISSUER'),
		config('OKTA_SCOPE')
	)
#Hello world route

def validate_remotely(token, issuer, clientId, clientSecret):
	headers = {
		'accept': 'application/json',
		'cache-control': 'no-cache',
		'content-type': 'application/x-www-form-urlencoded', }	
	data = {
		'client_id': clientId,
		'client_secret': clientSecret,
		'token': token, }
	
	url = issuer + '/v1/introspect'
	response = httpx.post(url, headers=headers, data=data)
	return response.status_code == httpx.codes.OK and response.json()['active']

def validateremote(token: str = Depends(oauth2_scheme)):
	res = validate_remotely(
		token,
		config('OKTA_ISSUER'),
		config('OKTA_CLIENT_ID'),
		config('OKTA_CLIENT_SECRET'))
	if res:
		return True
	else:
		raise HTTPException(status_code=400)

#def validate(token: str = Depends(oauth2_scheme)):
#	res = validate_remotely(
#		token,
#		config('OKTA_ISSUER'),
#		config('OKTA_CLIENT_ID'),
#		config('OKTA_CLIENT_SECRET'))
#	if res:
#		return True
#	else:
#		raise HTTPException(status_code=400)


def validate(token: str = Depends(oauth2_scheme)):
	try:
		res = validate_locally(
			token,
			config('OKTA_ISSUER'),
			config('OKTA_AUDIENCE'),
			config('OKTA_CLIENT_ID'))
		return bool(res)
	except Exception:
		raise HTTPException(status_code=403)


class Item(BaseModel):
        id: int
        name: str

@app.get('/items', response_model=List[Item])
def read_items(valid: bool = Depends(validate)):
        return [
                Item.parse_obj({'id': 1, 'name': 'red ball'}),
                Item.parse_obj({'id': 2, 'name': 'blue square'}),
                Item.parse_obj({'id': 3, 'name': 'purple ellipse'}),]

@app.get('/itemsremote', response_model=List[Item])
def read_items(valid: bool = Depends(validateremote)):
	return [
		Item.parse_obj({'id': 1, 'name': 'red ball'}),
		Item.parse_obj({'id': 2, 'name': 'blue square'}),
		Item.parse_obj({'id': 3, 'name': 'purple ellipse'}),]


def validatelocal(token: str = Depends(oauth2_scheme)):
	try:
		res = validate_locally(
			token,
			config('OKTA_ISSUER'),
			config('OKTA_AUDIENCE'),
			config('OKTA_CLIENT_ID')
		)
		return bool(res)
	except Exception:
		raise HTTPException(status_code=403)

# Protected, get items route
@app.get('/itemslocal', response_model=List[Item])
def read_items(valid: bool = Depends(validatelocal)):
		return [
			Item.parse_obj({'id': 1, 'name': 'red ball'}),
			Item.parse_obj({'id': 2, 'name': 'blue square'}),
			Item.parse_obj({'id': 3, 'name': 'purple ellipse'}),]

@app.get("/")
def read_root():
	return {"Hello":"World"};
