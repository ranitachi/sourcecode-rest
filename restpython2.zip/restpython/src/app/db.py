from typing import Tuple
from sqlalchemy import (Column, DateTime, Integer, MetaData, String, Table, create_engine)
from sqlalchemy.sql import func
import os
import asyncio
import aiomysql
from sqlalchemy.ext.asyncio import create_async_engine

# DATABASE_URL = "mysql+aiomysql://api_user:2021#Pass@10.184.0.2/api_example"
DATABASE_URL = os.getenv("DATABASE_URL")
engine = create_async_engine(DATABASE_URL,
	execution_options={ "isolation_level": "AUTOCOMMIT"})
metadata = MetaData()
print(DATABASE_URL)

def timestamps() -> Tuple[Column, Column]: # jika diperlukan untuk database real
	return (
		Column("create_time", TIMESTAMP(timezone=True), server_default=func.now(), nullable=False),
		Column("update_time", TIMESTAMP(timezone=True), server_default=func.now(), nullable=False, onupdate=func.now())
	)

users = Table(
 "user",
 metadata,
 Column("id", Integer, primary_key=True),
 Column("firstname", String(100)),
 Column("lastname", String(100)),
 # timestamps()
)
