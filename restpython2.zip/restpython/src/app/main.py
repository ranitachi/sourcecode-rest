from fastapi import FastAPI
from app.db import engine, metadata
from app.api import users,ping

app = FastAPI()
app.include_router(ping.router)
app.include_router(users.router, prefix="/users", tags=["users"])
