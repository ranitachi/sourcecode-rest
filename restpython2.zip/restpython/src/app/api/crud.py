from app.api.models import UserSchema, UserDB
from app.db import users, engine
from sqlalchemy import select, insert, update, delete

async def post(payload: UserSchema) -> int:
 async with engine.connect() as conn:
  query = insert(users).values(firstname=payload.firstname, lastname=payload.lastname)
  hasil= await conn.execute(query)
  return hasil.is_insert

async def get(id:int) -> UserDB:
 async with engine.connect() as conn:
  print("id:",id)
  query = select(users).where(id == users.c.id)
  hasil = await conn.execute(query)
  return hasil.fetchone()

async def get_all():
 async with engine.connect() as conn:
  query = select(users)
  hasil = await conn.execute(query)
  return hasil.fetchall()

async def put(id: int, payload: UserSchema) -> int:
 async with engine.connect() as conn:
  query = (update(users).where(id == users.c.id)
   .values(firstname=payload.firstname, lastname=payload.lastname))
  hasil= await conn.execute(query) 
  return hasil.rowcount 

async def delete(id: int) -> int:
 async with engine.connect() as conn:
  query = users.delete().where(id == users.c.id)
  hasil= await conn.execute(query) 
  return hasil.rowcount
