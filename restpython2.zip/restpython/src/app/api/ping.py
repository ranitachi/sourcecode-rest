from fastapi import APIRouter
import mysql.connector
import os

db = mysql.connector.connect(
 host=os.environ['HOSTLOCAL'],
 database="api_example",
 user="api_user",
 passwd="!!api_user!!"
)

router = APIRouter()
@router.get("/ping")
#@app.get("/ping")
async def pong():
	return {"ping": "pong!"}

@router.get("/db")
async def pong():
	if db.is_connected():
		return {"pesan":"database connected"}
