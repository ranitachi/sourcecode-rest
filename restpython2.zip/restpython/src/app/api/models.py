from pydantic import BaseModel
class UserSchema(BaseModel):
	firstname: str
	lastname: str
class UserDB(UserSchema):
	id: int
