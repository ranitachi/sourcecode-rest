from app.api import crud
from app.api.models import UserDB, UserSchema
from fastapi import APIRouter, HTTPException
from fastapi.responses import UJSONResponse
from typing import List
router = APIRouter()

@router.post("/", response_model=UserDB, status_code=201)
async def create_user(payload: UserSchema):
 user_id = await crud.post(payload)
 response_object = {
  "id": '',
  "firstname": payload.firstname,
  "lastname": payload.lastname,
 }
 return response_object

@router.get("/{id}", response_model=UserDB)
async def read_user(id: int):
 user = await crud.get(id)
 if not user: 
  raise HTTPException(status_code=404, detail="User not found") 
 return user

@router.put("/{id}", response_class=UJSONResponse)
async def update_user(id: int, payload: UserSchema):
 count = await crud.put(id, payload)
 response_object = { 
  "affectedrow": count
 }
 return [response_object]

@router.delete("/{id}", response_class=UJSONResponse)
async def delete_user(id: int):
 count = await crud.delete(id)
 response_object = { 
  "affectedrow": count
 }
 return [response_object]

@router.get("/", response_model=List[UserDB])
async def read_all_user():
 return await crud.get_all()
