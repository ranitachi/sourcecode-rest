const env = process.env
const config = {
  db: {
    host: env.DB_HOST || 'localhost',
    user: env.DB_USER || 'api_user',
    password: env.DB_PASSWORD || '!!api_user!!',
    database: env.DB_NAME || 'api_example'
  },
  listPerPage: env.LIST_PER_PAGE || 10
}
module.exports = config
