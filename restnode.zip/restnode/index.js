require('dotenv').config()
const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const port = process.env.PORT || 3030
const userRouter = require('./routes/user')

const authMiddleware = require('./auth')
app.use(bodyParser.json())

app.use(authMiddleware)

app.use(
  bodyParser.urlencoded({
    extended: true
  })
)

app.use('/user', userRouter)

app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500
  console.error(err.message, err.stack)
  res.status(statusCode).json({ message: err.message })
})

/* app.get('/', (req, res) => {
  res.json({ message: 'ok' })
}) */
app.listen(port,()=> {
  console.log(`listening at port ${port}`)
})
